import { useState } from "react";

function ComplaintRegister() {
  const [name, setName] = useState("");
  const [complaint, setComplaint] = useState("");
  const [id, setId] = useState(0);
  function handleName(event) {
    setName(event.target.value);
  }
  function handleComplaint(event) {
    setComplaint(event.target.value);
  }
  function handleSubmit(e) {
    e.preventDefault();
    window.alert(
      `Thanks ${name}\n Your Complaint was Submitted.\n Transaction ID is: ${id}`
    );
    setId(id + 1);
  }

  return (
    <div className="complaint-page">
      <h1>Register your complaints here!!!</h1>
      <div>
        <form>
          <div className="data-container">
            <label>Name: </label>
            <input type="text" value={name} onChange={handleName} />
          </div>
          <div className="data-container">
            <label>Complaint: </label>
            <textarea value={complaint} onChange={handleComplaint} />
          </div>

          <div className="btn">
            <button onClick={handleSubmit}>Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ComplaintRegister;
