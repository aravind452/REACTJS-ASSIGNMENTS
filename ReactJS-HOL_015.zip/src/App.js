import "./App.css";
import ComplaintRegister from "./ComplaintRegister";

function App() {
  return (
    <div className="App">
      <ComplaintRegister></ComplaintRegister>
    </div>
  );
}

export default App;
