function App() {
  return <h1>Welcome the First session Of React!</h1>;
}

export default App;
