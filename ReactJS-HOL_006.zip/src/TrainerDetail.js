import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import trainersMock from "./TrainersMock";

function TrainerDetail() {
  const { id } = useParams();
  const [thisTraniner, setThisTrainer] = useState({});

  useEffect(() => {
    function getTrainer() {
      let trainer = {};
      trainer = trainersMock.filter((item) => item.trainerId === id)[0];
      setThisTrainer(trainer);
    }
    if (id && trainersMock) {
      getTrainer();
    }
  }, [id]);

  return (
    <div>
      <h1>Trainers Details</h1>
      <p>
        <b>{thisTraniner && thisTraniner.name} </b>
      </p>
      <p>{thisTraniner && thisTraniner.email}</p>
      <p>{thisTraniner && thisTraniner.phone}</p>
      {thisTraniner.skills && (
        <ul>
          {thisTraniner.skills.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
export default TrainerDetail;
