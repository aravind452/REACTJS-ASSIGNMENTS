import React from "react";
import { Link } from "react-router-dom";
import trainersMock from "./TrainersMock";
function TrainersList() {
  return (
    <div>
      <h1>Trainers List</h1>
      <ul>
        {trainersMock.map((item, index) => (
          <li key={index}>
            <Link to={`/${item.trainerId}`}>{item.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TrainersList;
