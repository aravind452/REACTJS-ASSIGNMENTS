function Home() {
  return (
    <div>
      <h1>Welcome to My Academy trainers page</h1>
    </div>
  );
}
export default Home;
