import "./App.css";
import Home from "./Home";
import TrainersList from "./TrainersList";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import TrainerDetail from "./TrainerDetail";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <div>
          <h1>My Academy Trainers App</h1>
          <div className="nav-links">
            <Link to="/" className="home-nav-link">
              Home
            </Link>
            <Link to="/trainers" className="trainers-nav-link">
              Show Trainers
            </Link>
          </div>
        </div>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/trainers" element={<TrainersList />} />
          <Route exact path="/:id" element={<TrainerDetail />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
