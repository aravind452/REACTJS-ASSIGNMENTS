import logo from "./logo.svg";
import "./App.css";
import { EmployeesData } from "./Employee";
import EmployeesList from "./EmployeesList";
import { useState } from "react";
import { ThemeContextProvider, useTheme } from "./ThemeContext";
function App() {
  const Employees = EmployeesData;
  return (
    <>
      <ThemeContextProvider>
        <EmployeesList employees={Employees} />
      </ThemeContextProvider>
    </>
  );
}

export default App;
