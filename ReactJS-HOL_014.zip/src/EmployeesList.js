import EmployeeCard from "./EmployeeCard";
import { useTheme } from "./ThemeContext";
function EmployeesList(props) {
  const { setTheme } = useTheme();
  return (
    <div>
      <div>
        <label>SELECT A THEME </label>
        <select onChange={(e) => setTheme(e.target.value)}>
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </div>
      <h1>Employees List</h1>
      {props.employees.map((employee) => (
        <EmployeeCard employee={employee} key={employee.id} />
      ))}
    </div>
  );
}
export default EmployeesList;
