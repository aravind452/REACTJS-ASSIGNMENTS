function BookDetail(props) {
  return (
    <div>
      <h1>BOOK DETAILS</h1>
      {props.book.map((book, index) => (
        <div key={index}>
          <h3>{book.bname}</h3>
          <h4>{book.price}</h4>
        </div>
      ))}
    </div>
  );
}

export default BookDetail;
