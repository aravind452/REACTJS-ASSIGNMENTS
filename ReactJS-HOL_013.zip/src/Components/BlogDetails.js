function BlogDetails(props) {
  return (
    <div>
      <h1>Blog Details</h1>
      {props.blog.map((blog, index) => (
        <div key={index}>
          <h2>{blog.blogname}</h2>
          <h4>{blog.author}</h4>
          <p>{blog.content}</p>
        </div>
      ))}
    </div>
  );
}

export default BlogDetails;
