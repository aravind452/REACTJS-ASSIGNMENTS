import "./App.css";
import BookDetail from "./Components/BookDetail";
import CourseDetails from "./Components/CourseDetails";
import BlogDetails from "./Components/BlogDetails";

function App() {
  const bookDetails = [
    {
      bname: "Master React",
      price: 670,
    },
    {
      bname: "Deep Dive into Angular",
      price: 800,
    },
    {
      bname: "Monog Essentials",
      price: 450,
    },
  ];

  const courseDetails = [
    {
      cname: "Angular",
      date: "4/5/2021",
    },
    {
      cname: "React",
      date: "6/3/2022",
    },
  ];

  const blogDetails = [
    {
      blogname: "React Learning",
      author: "Stephen Biz",
      content: "Welcome to React!",
    },
    {
      blogname: "Installation",
      author: "Schewzdenier",
      content: "You can install from npm",
    },
  ];

  return (
    <div>
      <div className="div-container">
        <div>
          <BookDetail book={bookDetails} />
        </div>

        <div className="line"></div>
        <div>
          <CourseDetails course={courseDetails} />
        </div>
        <div className="line"></div>
        <div>
          <BlogDetails blog={blogDetails} />
        </div>
      </div>
    </div>
  );
}

export default App;
