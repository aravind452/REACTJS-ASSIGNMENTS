import "./App.css";
import Posts from "./Posts";

function App() {
  return (
    <div>
      <Posts></Posts>
    </div>
  );
}

export default App;
