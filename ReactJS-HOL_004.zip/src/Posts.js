import React from "react";
class Posts extends React.Component {
  constructor(props) {
    super(props);
    //Post = new Post();
    this.state = {
      error: false,
    };
  }

  componentDidCatch(error) {
    this.setState({
      error: true,
    });
    alert(error.message);
  }

  render() {
    return <div>{!this.state.error && <Display />}</div>;
  }
}

class Display extends React.Component {
  constructor(props) {
    super(props);
    //Post = new Post();
    this.state = {
      posts: [],
    };
  }

  loadPosts() {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((res) => res.json())
      .then((res) => this.setState({ posts: res }));
  }

  componentDidMount() {
    this.loadPosts();
  }
  render() {
    return (
      <div>
        <h1 align="center">REST API</h1>
        {this.state.posts &&
          this.state.posts.map((post) => (
            <div>
              <h3>User ID: {post.id}</h3>
              <p>
                <b>Title: </b> {post.title}
              </p>
              <p>
                <b>Body: </b>
                {post.body}
              </p>
            </div>
          ))}
      </div>
    );
  }
}
export default Posts;
