import { useEffect, useState } from "react";

function Register() {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [mail, setMail] = useState("");
  const [error, setError] = useState({});

  function handleName(event) {
    setName(event.target.value);
  }

  function handleMail(event) {
    setMail(event.target.value);
  }

  function handlePassword(event) {
    setPassword(event.target.value);
  }

  function validate() {
    if (name.length < 5) {
      alert("Full Name must be 5 characters long!");
    }
    if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(mail)) {
      alert("Email is not valid!");
    }
    if (password.length < 9) {
      alert("Password must be 8 characters long!");
    } else {
      setError(0);
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    validate();
  }

  return (
    <div className="div-container">
      <h1>Register Here!!!</h1>
      <div>
        <form>
          <div className="input-container">
            <label>Name: </label>
            <input type="text" value={name} onChange={handleName} />
          </div>
          <div className="input-container">
            <label>Email: </label>
            <input type="email" value={mail} onChange={handleMail} />
          </div>
          <div className="input-container">
            <label>Password: </label>
            <input type="password" value={password} onChange={handlePassword} />
          </div>

          <button onClick={handleSubmit}>Submit</button>
        </form>
      </div>
    </div>
  );
}

export default Register;
