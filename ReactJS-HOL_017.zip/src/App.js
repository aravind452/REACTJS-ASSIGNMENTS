import logo from "./logo.svg";
import "./App.css";
import GetUser from "./GetUser";

function App() {
  return (
    <div className="App">
      <GetUser />
    </div>
  );
}

export default App;
