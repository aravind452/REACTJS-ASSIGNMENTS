import Axios from "axios";
import { useEffect, useState } from "react";

function GetUser() {
  const [data, setData] = useState({});

  useEffect(() => {
    const getUserDetails = async () => {
      await Axios.get("https://api.randomuser.me/").then((res) => {
        setData(res.data.results[0]);
      });
    };

    getUserDetails();
  }, []);
  return (
    <div>
      {data.name && (
        <div>
          <h1>{`${data.name.title} ${data.name.first} ${data.name.last}`}</h1>

          <img src={data.picture.large} alt={"img"}></img>
        </div>
      )}
    </div>
  );
}

export default GetUser;
