function ListofIndianPlayers(props) {
  return (
    <ul>
      {props.IndianPlayers.map((item, index) => (
        <li>Mr. {item}</li>
      ))}
    </ul>
  );
}

export default ListofIndianPlayers;
