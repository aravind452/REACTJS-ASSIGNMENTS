function Scorebelow70(props) {
  return (
    <div>
      <ul>
        {props.players.map((item, index) => {
          if (item.score <= 70) {
            return (
              <li key={index}>
                Mr. {item.name} {item.score}
              </li>
            );
          }
        })}
      </ul>
    </div>
  );
}

export default Scorebelow70;
