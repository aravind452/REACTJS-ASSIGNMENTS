function ListofPlayers(props) {
  return (
    <div>
      <ul>
        {props.players.map((item, index) => (
          <li key={index}>
            Mr. {item.name} {item.score}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ListofPlayers;
