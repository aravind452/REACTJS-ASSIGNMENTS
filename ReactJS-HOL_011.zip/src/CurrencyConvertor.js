import { useState } from "react";

function CurrencyConvertor() {
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("");

  function handleSubmit(event) {
    event.preventDefault();

    if (currency === "euro" || currency === "EURO" || currency === "Euro") {
      window.alert(`Converting to Euro Amount is ${amount * 90}`);
    } else {
      window.alert("Invalid Currency");
    }
  }
  function handleAmountChange(event) {
    setAmount(event.target.value);
  }
  function handleCurrencyChange(event) {
    setCurrency(event.target.value);
  }

  return (
    <div>
      <h1 style={{ color: "green" }}>Currency Convertor!!!</h1>
      <form>
        <div className="input-container">
          <label>Amount: </label>
          <input
            type="number"
            name="amount"
            value={amount}
            onChange={handleAmountChange}
          />
        </div>
        <div className="input-container">
          <label>Currency: </label>
          <textarea value={currency} onChange={handleCurrencyChange}></textarea>
        </div>
        <div className="btn-class">
          <button className="sub-btn" onClick={handleSubmit}>
            Submit
          </button>
        </div>
      </form>
    </div>
  );
}

export default CurrencyConvertor;
