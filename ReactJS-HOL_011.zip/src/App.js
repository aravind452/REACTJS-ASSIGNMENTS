import { useState } from "react";
import "./App.css";
import CurrencyConvertor from "./CurrencyConvertor";

function App() {
  const [count, setCount] = useState(0);

  function handleIncrement() {
    setCount(count + 1);
    window.alert("Hello, Member1");
  }

  function handleDecrement() {
    if (count) setCount(count - 1);
  }

  function alertMessage(message) {
    window.alert(message);
  }

  function clickMe() {
    window.alert("I was clicked");
  }
  return (
    <div className="home-page">
      <p>{count}</p>
      <button onClick={handleIncrement}>Increment</button>
      <button onClick={handleDecrement}>Decrement</button>
      <button
        onClick={() => {
          alertMessage("welcome");
        }}
      >
        Say Welcome
      </button>
      <button onClick={clickMe}>Click on me</button>

      <CurrencyConvertor />
    </div>
  );
}

export default App;
