import { useState } from "react";
import "./App.css";
import GuestUser from "./GuestUser";
import LoggedInUSer from "./LoggedInUser";

function App() {
  const [isLogin, setIsLogin] = useState(false);

  return (
    <div className="home">
      {isLogin ? (
        <LoggedInUSer logout={setIsLogin} />
      ) : (
        <GuestUser login={setIsLogin} />
      )}
    </div>
  );
}

export default App;
