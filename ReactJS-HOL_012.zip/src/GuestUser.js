function GuestUser(props) {
  return (
    <div>
      <h1>Please sign up.</h1>
      <button
        onClick={() => {
          props.login(true);
        }}
      >
        Login
      </button>
    </div>
  );
}

export default GuestUser;
