function LoggedInUSer(props) {
  return (
    <div>
      <h1>Welcome back</h1>
      <button
        onClick={() => {
          props.logout(false);
        }}
      >
        Logout
      </button>
    </div>
  );
}

export default LoggedInUSer;
