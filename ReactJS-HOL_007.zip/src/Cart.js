import "./OnlineShop.css";
function Cart(props) {
  return (
    <div className="mydiv">
      <table border="2">
        <tr>
          <th>Item</th>
          <th>Price</th>
        </tr>
        {props.item.map((item) => (
          <tr>
            <td>{item.itemname}</td>
            <td>{item.price}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}
export default Cart;
