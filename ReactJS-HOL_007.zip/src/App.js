import "./App.css";
import { OnlineShopping } from "./OnlineShopping";

function App() {
  return (
    <div className="App">
      <OnlineShopping></OnlineShopping>
    </div>
  );
}

export default App;
