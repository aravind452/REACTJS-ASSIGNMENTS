import "./App.css";
import Image from "./Asserts/img1.jpg";

function App() {
  const element = "Office Space";
  const jsxatt = (
    <img src={Image} width="150px" height="150px" alt="Office Space" />
  );
  const itemName = [
    { name: "DBS", rent: 50000, address: "Chennai" },
    { name: "ABC", rent: 60000, address: "Bangalore" },
    { name: "BCD", rent: 45000, address: "Delhi" },
    { name: "HCD", rent: 70000, address: "Kerala" },
  ];

  return (
    <div className="homepage">
      <h1>{element}, at Affordable Range</h1>
      {itemName.map((item, index) => (
        <div key={index}>
          {jsxatt}
          <h1>Name: {item.name}</h1>
          <h3 style={item.rent < 60000 ? { color: "green" } : { color: "red" }}>
            Rent: Rs. {item.rent}
          </h3>
          <h3>Address: {item.address}</h3>
        </div>
      ))}
    </div>
  );
}

export default App;
