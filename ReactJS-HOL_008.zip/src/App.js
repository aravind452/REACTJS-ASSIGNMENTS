import React, { useState } from "react";
import "./App.css";

function App() {
  const [entry, setUpdateEntry] = useState(0);

  function login() {
    setUpdateEntry(entry + 1);
  }

  const [exit, setUpdateExit] = useState(0);
  function leave() {
    if (entry && entry !== exit) {
      setUpdateExit(exit + 1);
    }
  }

  return (
    <div className="login-section">
      <div className="container">
        <button onClick={login}>Login</button>
        <p>{entry} People Entered!!!</p>
      </div>
      <div className="container">
        <button onClick={leave}>Exit</button>
        <p>{exit} People Left!!!</p>
      </div>
    </div>
  );
}

export default App;
